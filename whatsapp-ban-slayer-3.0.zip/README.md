# whatsapp-ban-slayer-3.0

Instalação ( Termux )

pkg install git 

pkg install python 

pkg install python3 

git clone https://github.com/slayerkk/whatsapp-ban-slayer-3.0

cd whatsapp-ban-slayer-3.0

python3 main.py

- Divirta-se
